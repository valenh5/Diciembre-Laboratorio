public class Cpu extends Componentes{
    public Cpu(String modelo, String fabricante, int precio, int stock) {
        super(modelo, fabricante, precio, stock);
    }
}
