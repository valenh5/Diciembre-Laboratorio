public enum MetodoImpresion {
    Inyeccion, Laser;
}
