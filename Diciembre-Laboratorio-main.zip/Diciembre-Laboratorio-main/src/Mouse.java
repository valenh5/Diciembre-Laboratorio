public class Mouse extends DispositivoEntrada{
    public Mouse(String modelo, String fabricante, int precio, int stock, String tipoConector, String puertos) {
        super(modelo, fabricante, precio, stock, tipoConector, puertos);
    }

}
