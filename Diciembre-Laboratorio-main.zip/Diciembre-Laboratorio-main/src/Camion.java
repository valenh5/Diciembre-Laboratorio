public class Camion extends Vehiculo{
    public Camion(String marca, String patente, int cantRuedas) {
        super(marca, patente, cantRuedas);
    }

}
