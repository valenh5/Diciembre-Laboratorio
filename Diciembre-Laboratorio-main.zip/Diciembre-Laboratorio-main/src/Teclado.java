public class Teclado extends DispositivoEntrada{
    public Teclado(String modelo, String fabricante, int precio, int stock, String tipoConector, String puertos) {
        super(modelo, fabricante, precio, stock, tipoConector, puertos);
    }
}
