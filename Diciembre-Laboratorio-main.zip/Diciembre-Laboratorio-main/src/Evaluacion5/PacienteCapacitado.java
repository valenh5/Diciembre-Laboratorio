package Evaluacion5;

public interface PacienteCapacitado {
    public boolean esApto();
    public int precio();
}
