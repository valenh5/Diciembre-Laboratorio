package Evaluacion5;

public enum Sexo {
    HOMBRE, MUJER;
}
