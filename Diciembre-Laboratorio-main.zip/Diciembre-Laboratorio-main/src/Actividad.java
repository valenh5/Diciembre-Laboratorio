public enum Actividad {
    FUTBOL,
    HANDBALL,
    VOLLEY,
    ARQUERIA,
    TAEKWONDO,
    REMO,
    ESGRIMA,
    AJEDREZ,
    TENIS;

    private Actividad() {
    }
}
