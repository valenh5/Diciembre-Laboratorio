package Evaluacion4;

public class FaltaCombustibleException extends Exception{
    public FaltaCombustibleException(String message) {
        super(message);
    }
}
