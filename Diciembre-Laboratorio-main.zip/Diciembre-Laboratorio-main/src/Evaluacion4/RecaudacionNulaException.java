package Evaluacion4;

public class RecaudacionNulaException extends Exception{
    public RecaudacionNulaException(String message) {
        super(message);
    }
}
