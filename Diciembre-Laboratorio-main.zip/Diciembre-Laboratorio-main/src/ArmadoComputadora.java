public class ArmadoComputadora {
}
