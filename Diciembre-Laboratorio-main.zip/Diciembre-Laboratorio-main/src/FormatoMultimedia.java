public enum FormatoMultimedia {
    MP4, AVI, WAV, MP3;
}
